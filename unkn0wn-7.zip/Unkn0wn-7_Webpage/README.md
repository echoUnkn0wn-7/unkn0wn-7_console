unkn0wn-7@console // $ echo 'new arg' > ./trixam.txt
